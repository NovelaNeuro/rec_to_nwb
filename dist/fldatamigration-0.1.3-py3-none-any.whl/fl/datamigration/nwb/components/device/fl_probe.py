class FlProbe:

    def __init__(self, metadata, probe_id):
        self.metadata = metadata
        self.probe_id = probe_id