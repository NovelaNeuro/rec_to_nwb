class FlFLElectrodeGroup:

    def __init__(self, metadata, device):
        self.metadata = metadata
        self.device = device