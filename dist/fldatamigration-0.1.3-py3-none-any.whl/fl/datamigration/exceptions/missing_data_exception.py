class MissingDataException(Exception):
    pass
