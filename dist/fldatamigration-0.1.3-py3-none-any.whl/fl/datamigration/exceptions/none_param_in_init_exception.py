class NoneParamInInitException(Exception):
    pass
