class NotCompatibleMetadata(Exception):
    pass