from builtins import open
from setuptools import setup, find_packages

with open('requirements-min.txt', 'r') as fp:
    # replace == with >= and remove trailing comments and spaces
    reqs = [x.replace('==', '>=').split('#')[0].strip() for x in fp]
    reqs = [x for x in reqs if x]  # remove empty strings

setup(
    name='fldatamigration',
    version='0.1.003',
    author='Novela Neurotech',
    url="https://github.com/NovelaNeuro/fldatamigration",
    packages=find_packages(),
    package_data={'': ['logging.conf']},
    install_requires=reqs,
    description='Data transformation from rec binary files into NWB 2.0 format',
    platforms='Posix; MacOS X; Windows',
    python_requires='==3.7.4',
)
