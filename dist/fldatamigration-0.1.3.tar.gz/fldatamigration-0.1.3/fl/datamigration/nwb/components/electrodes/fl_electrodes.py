class FlElectrode:

    def __init__(self, electrode_group):
        self.electrode_group = electrode_group
