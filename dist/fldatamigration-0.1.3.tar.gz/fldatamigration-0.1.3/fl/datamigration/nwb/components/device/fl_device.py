class FlDevice:

    def __init__(self, name):
        self.name = name