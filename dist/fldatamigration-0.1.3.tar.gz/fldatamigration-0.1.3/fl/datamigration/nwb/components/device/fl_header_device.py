class FlHeaderDevice:

    def __init__(self, name, global_configuration):
        self.name = name
        self.global_configuration = global_configuration