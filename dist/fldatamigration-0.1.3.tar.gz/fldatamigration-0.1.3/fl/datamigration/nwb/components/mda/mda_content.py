class MdaContent:

    def __init__(self, mda_data, mda_timestamps):
        self.mda_data = mda_data
        self.mda_timestamps = mda_timestamps
