class FlApparatus:

    def __init__(self, edges, nodes):
        """internal representation of apparatus data"""

        self.edges = edges
        self.nodes = nodes
