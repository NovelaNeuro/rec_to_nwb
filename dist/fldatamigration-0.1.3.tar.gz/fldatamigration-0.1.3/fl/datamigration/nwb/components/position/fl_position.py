class FlPosition:

    def __init__(self, position_data, timestamps):
        self.position_data = position_data
        self.timestamps = timestamps